import React from 'react'
import {useEffect,useState} from'react';
export default function Fee() {
  const[user,setUser]=useState([])
  useEffect(()=>{
    fetch('https://jsonplaceholder.typicode.com/users')
    .then(res=>res.json())
    .then(res=>setUser(res))
  }
  )
  console.log(user)
  return (
    <div>
    {user.map(u=>(
      <div>{u.name},{u.id},{u.email}</div>
    ))}
    </div>
  )
}
