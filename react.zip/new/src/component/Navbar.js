import React from 'react';
import './nav.css'
function MyNavbar(){
  return (
    <nav className="navbar">
      <div className="navbar__logo">My Website</div>
      <ul className="navbar__links">
        <li className="navbar__item">
          <a href="#home" className="navbar__link">Home</a>
        </li>
        <li className="navbar__item">
          <a href="#about" className="navbar__link">About</a>
        </li>
        <li className="navbar__item">
          <a href="#services" className="navbar__link">Services</a>
        </li>
        <li className="navbar__item">
          <a href="#contact" className="navbar__link">Contact</a>
        </li>
      </ul>
    </nav>
  );
}

export default MyNavbar;
