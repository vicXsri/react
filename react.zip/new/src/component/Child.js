import React, { Component } from 'react'

class Child extends Component {
    onTrigger=(event)=>{
        this.props.parentCallback(event.target.myname.value);
        event.preventDefault();
    }
  render() {
    return (
      <div>
        <form onSubmit={this.onTrigger}>
            <input type = "text" name="myname" placeholder="Enter Name"/>
            <be/><br/>
            <input type = "submit" value = "Submit"/>
            <be/><br/>
        </form>
      </div>
    )
  }
}

export default Child