import React from 'react'
import './new.css'
export default function New() {
  return (
    <nav className='nav-design'>
    <div>Welcome</div>
    <ul className="nav-logo">
    <li className="nav-sin">
    <a href="home">Home</a>
    </li>
    <li className="nav-sin">
    <a href="contact">Contact</a>
    </li>
    <li className="nav-sin">
    <a href="signup">Signup</a>
    </li>
    <li className="nav-sin">
    <a href="login">Login</a>
    </li>
    </ul>
    </nav>
  )
}
