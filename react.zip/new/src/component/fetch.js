import { useEffect,useState } from "react";
import React from 'react'

export default function Fetch() {
    const[user,setUser]=useState([]);
    useEffect(()=>{
        fetch('http://jsonplaceholder.typicode.com/users')
        .then(res=>res.json())
        .then(res=>setUser(res))
    })
    console.log(user)
  return (
    <div className="main">
    {user.map(u=>(
        <div>{u.name},{u.id},{u.email}</div>
    ))}
    </div>
  )
}
