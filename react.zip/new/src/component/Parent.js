import React, { Component } from 'react'
import Child from './Child'
class Parent extends Component {
  state={name:"",}
  handleCallback=(childData)=>{
    this.setState({name:childData})
  }
  render() {
    const {name}=this.state;
    return (
      <div style={{textAlign:'center'}}>
        <h1>Child and Parent Components</h1>
        <Child parentCallback = {this.handleCallback}/>
        {name}
      </div>
    )
  }
}

export default Parent