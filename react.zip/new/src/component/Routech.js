import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import New from './New';
import Fee from './fetch';
//npm install react-router-dom --force
const App = () => {
  return (
    <Router>
      <nav>
        <ul>
          <li>
            <Link to="/">New</Link>
          </li>
          <li>
            <Link to="/page-two">Fee</Link>
          </li>
        </ul>
      </nav>
      <Routes>
        <Route path="/" element={<New />} />
        <Route path="/page-two" element={<Fee />} />
      </Routes>
    </Router>
  );
};

export default App;