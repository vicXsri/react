import React from 'react';



export default function Dropdown() {
  return (
    <div style={{textAlign:'center'}}>
      <select>
        <option value="fruit">Fruit</option>
        <option value="vegetable">Vegetable</option>
        <option value="meat">Meat</option>
        <option value="snacks">Snacks</option>
      </select>
    </div>
  );
};
