import React from 'react'
import { Card } from '@mui/material'
import CardMedia from '@mui/material/CardMedia'
import CardContent from '@mui/material/CardContent'
import Typography from '@mui/material/Typography'
import CardActions from '@mui/material/CardActions'
import Button from '@mui/material/Button'
/* 
npm install @mui/material
npm install @mui/icons-material
npm install @emotion/react
npm install @emotion/styled
npm install @mui/material @mui/styled-engine-sc styled-components
npm install @material/react-button --force
*/
export default function Materialui() {
  return (
    <Card sx={{maxWidth:345}}>
    <CardMedia component="img" height="140" image="https://5.imimg.com/data5/SELLER/Default/2022/9/RI/RZ/QZ/47977595/300-ml-paper-coke-glasses-1000x1000.jpg"
    alt="coke"/>
    <CardContent>
    <Typography >
    SKCET
    </Typography>
    <Typography >
    hello this is text
    </Typography>
    </CardContent>
    <CardActions>
        <Button size="small">share</Button>
        <Button size="small">learn</Button>
    </CardActions>
    </Card>
  )
}
