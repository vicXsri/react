import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Coke from './coke';
import Conditionalrender from './Conditionalrender';
import Cond from './component/Cond';
import Parent from './component/Parent';
import Materialui from './component/materialui';
import MyNavbar from './component/Navbar';
import New from './component/New';
import Fee from './component/fetch';
import Dropdown from './component/Dropdwon';
import App from './component/Routech';
const root = ReactDOM.createRoot(document.getElementById('root'))
root.render(
    <>
    <App/>
    </>
);  