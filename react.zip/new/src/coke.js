import React from "react";

class Cct extends React.Component{
    render(){
        return(
            <div>
                <h1>hello</h1>
            </div>
        );
    }
}
export default Cct

