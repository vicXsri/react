import React, { Component } from 'react'
//r
class Conditionalrender extends Component {
  render() {
    return (
      <div>
        <h1>hey</h1>
        </div>
    )
  }
}

export default Conditionalrender